# Esercizio: Bug hunt (Python)

Il file `esercizi.py` contiene quattro funzioni, ognuna con un bug nascosto.

## Cosa fare

1. Esegui i test: `python -m pytest -v`
2. Per ogni test che fallisce, scrivi cosa ti aspettavi e cosa è successo.
3. Individua la causa (usa `print`, il debugger o un test in più) e correggi il codice.
4. Non modificare i test.
5. Compila la dichiarazione d'uso dell'IA qui sotto.

## Livello d'uso dell'IA: B (tutor)

L'IA può spiegarti un errore o proporti una domanda guida. NON deve scrivere
la correzione. Se la usi, dichiaralo.

## Dichiarazione d'uso dell'IA
- Strumento usato: 
- Per cosa l'ho usato: 
- Prompt principali: 
- Cosa ho accettato: 
- Cosa ho modificato o respinto, e perché: 
- Come ho verificato i risultati: 

## Diario dei bug

| Funzione | Test che falliva | Causa | Correzione |
|---|---|---|---|
|  |  |  |  |
