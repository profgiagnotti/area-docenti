import pytest
from esercizi import media, e_palindromo, conta_vocali, massimo


# --- media ---
def test_media_tre_numeri():
    assert media([2, 4, 6]) == 4


def test_media_un_solo_numero():
    assert media([5]) == 5


# --- e_palindromo ---
def test_palindromo_semplice():
    assert e_palindromo("anna") is True


def test_non_palindromo():
    assert e_palindromo("casa") is False


def test_palindromo_con_apostrofo():
    assert e_palindromo("Ai lati d'Italia") is True


# --- conta_vocali ---
def test_vocali_nessuna():
    assert conta_vocali("xyz") == 0


def test_vocali_con_maiuscole():
    assert conta_vocali("Aiuola") == 5


# --- massimo ---
def test_massimo_positivi():
    assert massimo([1, 5, 3]) == 5


def test_massimo_negativi():
    assert massimo([-5, -2, -9]) == -2
