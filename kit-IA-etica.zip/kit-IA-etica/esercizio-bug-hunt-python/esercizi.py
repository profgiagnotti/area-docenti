"""Bug hunt: ogni funzione contiene UN errore nascosto.

Compito: eseguire i test, capire perché falliscono, trovare e correggere
i bug. Non è consentito modificare i test.
"""


def media(numeri):
    """Restituisce la media aritmetica di una lista non vuota di numeri."""
    totale = 0
    for n in numeri:
        totale += n
    return totale / (len(numeri) - 1)


def e_palindromo(testo):
    """True se il testo è palindromo, ignorando maiuscole, spazi e punteggiatura."""
    pulito = testo.lower().replace(" ", "")
    return pulito == pulito[::-1]


def conta_vocali(testo):
    """Conta le vocali (a, e, i, o, u) nel testo, maiuscole comprese."""
    return sum(1 for c in testo if c in "aeiou")


def massimo(lista):
    """Restituisce il valore massimo di una lista non vuota di numeri."""
    m = 0
    for x in lista:
        if x > m:
            m = x
    return m
