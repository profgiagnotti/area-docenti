# Prompt per il docente: generare materiali didattici

Controlla sempre ciò che l'IA produce: eseguilo, testalo, correggilo.

## Bug intenzionali (debugging)
```
Scrivi una funzione [linguaggio] che [descrizione], di circa 15 righe, con
esattamente 3 bug: un errore off-by-one, un caso limite non gestito, un errore
in una condizione. NON indicare dove sono. In una sezione separata aggiungi la
soluzione commentata e 5 test che falliscono a causa dei bug.
```
Verifica: esegui i test; confronta quanti bug esistono davvero.

## Variante personalizzata di un esercizio
```
Dato questo esercizio: [testo], crea 4 varianti con dati e contesto diversi ma
stessa difficoltà e stessi obiettivi. Per ognuna dammi i risultati attesi.
```

## Risposta dell'IA con errore volontario (caccia all'errore)
```
Spiega [argomento tecnico] in 200 parole inserendo UN errore sottile ma
verosimile. Non segnalarlo nel testo: indicalo in una sezione separata con la
spiegazione del perché è sbagliato.
```

## Scenari di guasto di rete
```
Proponi 6 guasti realistici per una rete Cisco didattica con VLAN, router e
DHCP. Per ciascuno: sintomo osservabile, comandi IOS di diagnosi, causa e
correzione. Evita guasti che richiedono hardware reale.
```

## Quiz con distrattori plausibili
```
Crea 8 domande a scelta multipla su [argomento] per studenti di [classe], con
3 distrattori plausibili ciascuna, la risposta corretta e una spiegazione di
una frase. Livello: [base / intermedio].
```

## Rubrica
```
Crea una rubrica a 3 livelli per valutare [compito] con i criteri: verifica
critica, comprensione, dichiarazione d'uso dell'IA, qualità del codice.
```
