# Patto d'aula sull'uso dell'intelligenza artificiale

Classe: ______  Anno scolastico: ______  Docente: ______

(Da adattare al regolamento d'istituto e al Piano d'Istituto sull'IA, se presente.)

## I nostri principi
1. Trasparenza: dichiaro quando e come uso l'IA.
2. Responsabilità: rispondo di ciò che consegno, anche se l'ha scritto uno strumento.
3. Verifica: controllo ogni risposta con test, esecuzione o documentazione.
4. Privacy: non inserisco dati personali, credenziali o codice riservato.
5. Integrità: non uso l'IA dove la consegna serve a misurare ciò che so fare io.
6. Equità: nessuno è obbligato a pagare; le attività funzionano anche senza strumenti.

## I tre livelli d'uso (indicati in ogni consegna)
- **Livello A – Senza IA**
- **Livello B – IA come tutor:** spiegazioni, revisione, test; non per scrivere la soluzione
- **Livello C – IA libera con dichiarazione:** anche per generare codice, purché dichiarato e compreso

## Cosa succede
- Se uso l'IA come previsto e lo dichiaro: nessun problema, anzi viene valutato positivamente.
- Se non dichiaro l'uso o uso l'IA oltre il livello consentito: ne parliamo insieme e
  rifaccio una parte del lavoro in classe. Le conseguenze disciplinari seguono il
  regolamento d'istituto.
- Se un compito è risolvibile solo copiando dall'IA, il docente rivede la consegna.

## Impegni del docente
- Indicare il livello in ogni consegna.
- Valutare anche verifica, comprensione e dichiarazione d'uso.
- Offrire alternative gratuite a chi non ha accesso agli strumenti.

Firma studente: ______________________  Data: ____________
