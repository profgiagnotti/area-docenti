# Libreria di prompt per lo studente

Sostituisci le parti tra [parentesi quadre]. Non incollare mai dati personali,
password, chiavi o codice riservato.

## 1. Code review del proprio compito
```
Agisci come revisore di codice per uno studente. Ti incollo il mio codice
[linguaggio] e la consegna. NON riscrivere il codice e NON darmi la soluzione.
Elenca i problemi per categoria (correttezza, leggibilità, casi limite,
efficienza) e per ciascuno spiegami il perché con una domanda guida.
Alla fine dimmi quale problema sistemare per primo.
```

## 2. Capire un messaggio di errore
```
Ho questo errore: [errore]. Il codice interessato è: [codice]. Non correggermi
il codice: spiegami cosa significa l'errore, dove guardare e che prova posso
fare per capire la causa.
```

## 3. Documentare il codice
```
Scrivi le docstring e un README per questo codice. Poi elenca le assunzioni che
hai fatto e le parti di cui non sei sicuro.
```
(Poi controlla ogni frase: cosa è falso o impreciso?)

## 4. Spiega prima tu, poi confronta
```
Ecco la mia spiegazione di questo codice: [spiegazione]. Dimmi cosa è corretto,
cosa è impreciso e cosa manca, senza riscrivere la spiegazione per intero.
```

## 5. Test e casi limite
```
Scrivi test [PyTest / JUnit / Mocha] per questa funzione. Includi casi normali e
casi limite. Indica quali comportamenti NON hai testato.
```

## 6. Guasto di rete in Packet Tracer
```
Sto cercando un guasto in una rete Cisco simulata con Packet Tracer.
Topologia (a parole): [...]
Sintomo: [...]
Output già raccolti: [...]
NON dirmi subito la causa. Proponi un ordine di verifica a strati (fisico,
collegamento, rete, applicazione) con i comandi IOS per ogni passo e cosa
devo aspettarmi se tutto è corretto.
```

## 7. Tutor socratico
```
Fai da tutor. Non darmi mai il codice completo. Quando ti chiedo aiuto rispondi
a livelli, uno alla volta, solo se te lo chiedo: 1) un indizio generale,
2) una domanda che mi porti alla causa, 3) al massimo 3 righe di codice.
Se ti chiedo tutta la soluzione ricordami che l'obiettivo è imparare.
```

## 8. Mettere alla prova una risposta dell'IA
```
Rileggi la tua risposta precedente. Elenca tre affermazioni che potrebbero
essere sbagliate o non verificabili e dimmi come potrei controllarle.
```

## Dopo ogni risposta dell'IA
- L'ho eseguita o testata?
- Ho controllato la documentazione ufficiale?
- Saprei spiegarla senza guardare la risposta?
- Ho compilato la dichiarazione d'uso?
