# Kit pronto all'uso: uso etico dell'IA a scuola

| File / cartella | A cosa serve |
|---|---|
| `prompt-studente.md` | Libreria di prompt per le otto attività |
| `prompt-docente.md` | Prompt per generare esercizi, bug, quiz, scenari di guasto |
| `patto-d-aula-IA.md` | Patto d'aula con i livelli A/B/C |
| `dichiarazione-uso-IA.md` | Blocco da incollare nei README |
| `rubrica-valutazione.md` | Rubrica da stampare |
| `livelli-IA-per-consegna.md` | Frasi pronte per indicare il livello d'uso in ogni consegna |
| `esercizio-bug-hunt-python/` | Esercizio con 4 bug (da dare agli studenti) |
| `SOLUZIONI-bug-hunt-DOCENTE.md` | Soluzioni (NON pubblicare nel repository degli studenti) |
| `packet-tracer-scenari-guasto.md` | Otto guasti di rete con diagnosi e soluzioni |
| `vscode-livello-A/` | Impostazione per disattivare i completamenti di Copilot |

## Uso in 5 passi

1. Adatta e condividi il patto d'aula.
2. Incolla la dichiarazione d'uso nei README dei compiti.
3. Scegli il livello A/B/C per ogni consegna.
4. Prova l'esercizio di bug hunt come prima attività: `python -m pytest -v`
   (prima della correzione 5 test falliscono e 4 passano).
5. Valuta con la rubrica e un breve colloquio.

## Attenzione
- Esercizio Python: verificato. Gli scenari di Packet Tracer sono schede testuali: devi
  costruire tu i file .pkt e controllare la sintassi sulla tua versione.
- L'impostazione di VS Code non è una barriera tecnica: funziona come regola concordata.
- Strumenti, piani e condizioni (anche di Copilot e GitHub Education) cambiano: verifica.
