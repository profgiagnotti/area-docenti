# Soluzioni (SOLO DOCENTE: non pubblicare nel repository modello)

| Funzione | Bug | Test che lo rivelano | Correzione |
|---|---|---|---|
| `media` | Divisore `len(numeri) - 1` invece di `len(numeri)` (off-by-one) | `test_media_tre_numeri`, `test_media_un_solo_numero` | `return totale / len(numeri)` |
| `e_palindromo` | Rimuove solo gli spazi, non la punteggiatura (apostrofo) | `test_palindromo_con_apostrofo` | `pulito = "".join(c for c in testo.lower() if c.isalnum())` |
| `conta_vocali` | Ignora le maiuscole | `test_vocali_con_maiuscole` | `for c in testo.lower()` oppure `c.lower() in "aeiou"` |
| `massimo` | Inizializza `m = 0`: sbaglia con tutti numeri negativi | `test_massimo_negativi` | `m = lista[0]` e ciclo sul resto |

## Esito atteso prima della correzione
5 test falliscono e 4 passano (quelli senza bug rilevabili).

## Idee per discutere in classe
- Perché `test_non_palindromo` e `test_palindromo_semplice` passano pur in presenza del bug?
  (Un test che passa non dimostra l'assenza di errori.)
- Quale test aggiungeresti per `media` con una lista vuota? Che comportamento è corretto?
- Chiedi a un assistente di IA di trovare i bug: li trova tutti? Spiega anche quello che NON è un bug?
