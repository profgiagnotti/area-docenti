# Rubrica: valutazione del lavoro con l'IA

| Criterio | Base | Intermedio | Avanzato |
|---|---|---|---|
| **Verifica critica** | Accetta le risposte senza controllare | Controlla alcune risposte | Verifica con test o fonti e documenta gli errori trovati |
| **Comprensione** | Non sa spiegare il codice | Spiega le parti principali | Spiega, modifica e giustifica le scelte |
| **Uso dichiarato** | Assente o generico | Presente ma incompleto | Completo, con prompt e decisioni |
| **Qualità dei prompt** | Richieste generiche | Richieste con contesto | Richieste con vincoli e verifica degli esiti |
| **Qualità del prodotto** | Non funziona | Funziona nei casi base | Funziona, è testato ed è leggibile |

Punteggio per criterio: Base = 1, Intermedio = 2, Avanzato = 3.

Studente: ______  Consegna: ______  Totale: ____ / 15

Colloquio breve (2 minuti): ☐ spiega il codice  ☐ sa modificarlo in diretta  ☐ motiva le scelte
