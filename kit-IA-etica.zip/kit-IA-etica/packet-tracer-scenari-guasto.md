# Otto scenari di guasto per Packet Tracer

Costruisci una rete base funzionante (due LAN con router, almeno una VLAN),
salvala, poi introduci UN guasto alla volta e salva un file per scenario.
Distribuisci agli studenti il file con il guasto (non questa scheda).

Metodo di diagnosi a strati (da consegnare agli studenti):

1. **Fisico:** cavi, LED, interfacce attive (`show ip interface brief`)
2. **Collegamento:** VLAN, trunk, MAC (`show vlan brief`, `show interfaces trunk`)
3. **Rete:** indirizzi, maschere, gateway, routing (`ipconfig`, `show ip route`)
4. **Servizi e filtri:** DHCP, ACL (`show access-lists`, `show ip dhcp binding`)

## Scenari

| # | Guasto introdotto | Sintomo | Comandi di diagnosi | Soluzione |
|---|---|---|---|---|
| 1 | Gateway errato su un PC | Il PC pinga i vicini della LAN ma non le altre reti | `ipconfig` sul PC | Correggere il default gateway |
| 2 | Interfaccia del router in shutdown | Nessun ping verso l'altra rete; LED rosso | `show ip interface brief` (stato administratively down) | `interface <if>` poi `no shutdown` |
| 3 | Subnet mask errata su un host | L'host raggiunge solo alcuni indirizzi | `ipconfig` | Impostare la maschera corretta |
| 4 | Porta dello switch nella VLAN sbagliata | Due PC della stessa VLAN non si pingano | `show vlan brief` | `switchport access vlan <id>` |
| 5 | Trunk che non permette una VLAN | Gli host di quella VLAN non comunicano tra switch | `show interfaces trunk` (VLAN allowed) | `switchport trunk allowed vlan add <id>` |
| 6 | ACL che blocca il traffico | Ping bloccato (Destination host unreachable o timeout) solo verso certe destinazioni | `show access-lists`, `show ip interface <if>` | Correggere o rimuovere la regola dell'ACL |
| 7 | Route statica con next hop sbagliato | Il pacchetto parte ma non torna o si ferma al router | `show ip route`, `traceroute` | Correggere con `no ip route ...` e `ip route ...` giusti |
| 8 | DHCP: manca l'helper address | I PC ricevono un indirizzo 169.254.x.x (APIPA) | `ipconfig`, `show ip dhcp binding` | `ip helper-address <server>` sull'interfaccia del gateway |

## Attività con l'IA

1. Lo studente descrive i sintomi e chiede all'IA un metodo di verifica (prompt 7.6 della guida).
2. Prova ogni comando suggerito in Packet Tracer: se un comando non funziona lo segnala.
3. Consegna il diario: comando, risultato, ipotesi, correzione, verifica finale con ping.

## Attenzioni
- L'IA non vede il file di Packet Tracer: ragiona solo sul testo che lo studente le fornisce.
- Può inventare comandi o sintassi di IOS: ogni suggerimento va provato.
- Non incollare configurazioni di reti reali dell'azienda o della scuola.
- Verifica la sintassi dei comandi sulla versione di Packet Tracer che usi.
