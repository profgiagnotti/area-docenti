## Dichiarazione d'uso dell'IA
- Strumento usato: [Copilot / ChatGPT / nessuno]
- Per cosa l'ho usato: [spiegare errori / code review / test / altro]
- Prompt principali: [copia 2-3 prompt significativi]
- Cosa ho accettato: [...]
- Cosa ho modificato o respinto, e perché: [...]
- Come ho verificato i risultati: [test, esecuzione, documentazione]
