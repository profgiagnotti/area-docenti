# Frasi pronte da incollare nel README di ogni consegna

## Livello A – Senza IA
> **Uso dell'IA: livello A (vietato).** Questa consegna misura le tue competenze di base.
> Non usare assistenti di IA (compresi i suggerimenti automatici dell'editor).

## Livello B – IA come tutor
> **Uso dell'IA: livello B (tutor).** Puoi usare l'IA per capire errori, ricevere una revisione
> del tuo codice e proporre test. Non puoi farle scrivere la soluzione. Compila la
> dichiarazione d'uso in fondo al file.

## Livello C – IA libera con dichiarazione
> **Uso dell'IA: livello C (libera con dichiarazione).** Puoi usare l'IA anche per generare
> codice, ma devi dichiararlo, verificarlo con test e saperlo spiegare in un colloquio breve.
> Compila la dichiarazione d'uso in fondo al file.
