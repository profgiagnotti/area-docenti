# Checklist di idoneità: Microsoft Learn for Educators e AWS Academy

Compila prima di candidarti. Segna ✅ / ❌ e annota la fonte.

## L'istituto

- [ ] L'ITS offre percorsi con diploma o certificazione riconosciuti? ______
- [ ] L'ITS è già membro di AWS Academy? (elenco ufficiale) ______
- [ ] L'ITS compare tra gli istituti MSLE nel menu di registrazione? ______
- [ ] Esiste un referente di direzione (futuro CPOC per AWS)? Nome: ______
- [ ] Gli studenti hanno un indirizzo email istituzionale? ______
- [ ] Chi autorizza il trattamento dei dati degli studenti sulle piattaforme? ______

## Il docente

- [ ] Ho un'email istituzionale o un documento che prova il mio ruolo
- [ ] Ho tempo per il corso introduttivo e per l'accreditamento (ore stimate: ____)
- [ ] Posso lavorare con materiali in inglese
- [ ] Ho un corso concreto in cui usare i laboratori

## Il corso

- [ ] Titolo: ______  Periodo: ______  N. studenti: ____
- [ ] Argomenti prevalenti: ☐ Azure/Microsoft  ☐ AWS  ☐ Altro ______
- [ ] Certificazione obiettivo: ______
- [ ] Gli studenti hanno almeno 18 anni? (requisito AWS: verifica sulla pagina ufficiale)

## Cosa verificare per iscritto prima di promettere qualcosa agli studenti

- [ ] Voucher: gratuito, scontato o a pagamento? Importo: ______
- [ ] Scadenza dei voucher e dei crediti: ______
- [ ] Dove si sostiene l'esame (centro, online) e in quale lingua: ______
- [ ] Credito per studente nei laboratori e cosa succede quando finisce: ______
