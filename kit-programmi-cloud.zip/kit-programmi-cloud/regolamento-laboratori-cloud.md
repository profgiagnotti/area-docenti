# Regolamento per l'uso dei laboratori cloud

Valido per tutte le attività su Azure, AWS e altre piattaforme cloud usate nel corso.

1. **Usa solo l'account del programma.** Non inserire carte di credito personali.
2. **Non usare dati reali o personali.** Nei laboratori si usano solo dati di esempio.
3. **Non condividere le credenziali**, nemmeno con i compagni.
4. **Spegni o elimina le risorse a fine lezione.** Una macchina virtuale accesa consuma credito.
5. **Controlla il credito residuo** all'inizio di ogni lezione.
6. **Non creare più risorse del necessario.** Segui le istruzioni dell'esercizio.
7. **Non usare i laboratori per progetti personali o commerciali.**
8. **Segnala subito al docente** errori, costi inattesi o accessi sospetti.
9. **Rispetta la sicurezza:** password robuste, autenticazione a più fattori quando richiesta.
10. **Il credito è limitato:** quando finisce non si prosegue con costi a carico dello studente.

Per accettazione:

Nome e cognome: __________________  Data: __________  Firma: __________________
