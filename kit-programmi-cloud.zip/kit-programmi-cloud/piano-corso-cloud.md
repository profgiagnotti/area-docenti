# Piano del corso cloud con laboratori e certificazione

- Corso: ______
- Docente: ______
- Periodo: ______
- Studenti: ______
- Programma: ☐ Microsoft Learn for Educators  ☐ AWS Academy  ☐ Entrambi

## Struttura (esempio, da adattare)

| Settimana | Argomento | Laboratorio | Credito stimato | Note |
|---|---|---|---|---|
| 1-2 | Concetti di cloud computing | Creazione account e primo servizio | basso | |
| 3-4 | Calcolo e archiviazione | Macchina virtuale, storage | medio | Ricordare di spegnere le risorse |
| 5-6 | Reti e sicurezza | Rete virtuale, regole di accesso | medio | |
| 7-8 | Database | Database gestito | medio | |
| 9-10 | Costi e governance | Budget e avvisi | basso | |
| 11-12 | Ripasso e esame di prova | Esame di prova | - | |

## Certificazione obiettivo (verifica i codici attuali sulle pagine ufficiali)

- Microsoft: certificazioni Fundamentals (ad esempio Azure Fundamentals)
- AWS: AWS Certified Cloud Practitioner

## Voucher e crediti

- Voucher docente: ☐ richiesto ☐ ricevuto – scadenza: ______
- Credito studenti: ______ per studente – scade: ______
- Voucher studenti: ______ (gratuito / scontato) – condizioni: ______

## Piano B

Se il credito finisce: ambienti locali con Docker o GitHub Codespaces.
