# Kit pronto all'uso: programmi accademici cloud per l'ITS

| File | A cosa serve |
|---|---|
| `checklist-idoneita.md` | Verifica preliminare dell'ITS, del docente e del corso |
| `lettera-direzione-ITS.md` | Modello di lettera per presentare il progetto alla direzione |
| `scheda-candidatura-AWS-Academy.md` | Dati da raccogliere prima di candidare l'istituto ad AWS Academy |
| `piano-corso-cloud.md` | Piano del corso con laboratori e certificazione obiettivo |
| `regolamento-laboratori-cloud.md` | Regole d'uso per gli studenti, da far firmare |
| `registro-crediti-e-voucher.csv` | Tabella per tracciare crediti, voucher e scadenze (si apre con Excel) |

## Come usarlo in 5 passi

1. Compila la checklist di idoneità.
2. Personalizza la lettera e consegnala alla direzione.
3. Iscriviti a Microsoft Learn for Educators e/o raccogli i dati per AWS Academy.
4. Compila il piano del corso e distribuisci il regolamento agli studenti.
5. Aggiorna il registro durante l'anno.

## Attenzione

- Condizioni, importi dei crediti e voucher cambiano e dipendono dal Paese e dall'istituto:
  verifica sempre le pagine ufficiali di Microsoft e AWS.
- I voucher gratuiti sono previsti soprattutto per i docenti; per gli studenti si parla
  in genere di sconti o promozioni con condizioni.
- Le procedure di iscrizione si fanno sui portali ufficiali: questo kit prepara i documenti,
  non invia nessuna richiesta.
