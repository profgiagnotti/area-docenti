# Modello di lettera alla direzione

Oggetto: Proposta di adesione ai programmi accademici cloud (Microsoft Learn for Educators / AWS Academy)

Gentile [Direttore/Direttrice],

con questa lettera Le propongo di aderire a [Microsoft Learn for Educators / AWS Academy]
per il corso [nome del corso], rivolto a [n.] studenti del [anno/biennio].

**Obiettivo didattico**
Offrire agli studenti ambienti cloud reali su cui esercitarsi e un percorso verso
la certificazione [nome certificazione], riconosciuta dal mercato del lavoro.

**Cosa offre il programma**
- Materiali didattici ufficiali, pronti per l'insegnamento.
- Laboratori cloud per gli studenti ([Azure for Students / Learner Lab]).
- Formazione per i docenti.
- Possibilità di voucher o sconti sugli esami di certificazione, con condizioni da
  verificare (non tutti i vantaggi sono gratuiti per gli studenti).

**Costi**
L'adesione è gratuita. Alcuni vantaggi sono scontati o limitati nel tempo.
Eventuali costi per gli esami degli studenti vanno definiti prima dell'avvio.

**Cosa serve da parte dell'istituto**
- Un referente per la candidatura (per AWS Academy, il Central Point of Contact).
- Autorizzazione al trattamento dei dati personali degli studenti sulle piattaforme.
- Tempo dei docenti per l'accreditamento: circa [__] ore.

**Calendario proposto**
- [mese]: iscrizione e accreditamento dei docenti
- [mese]: avvio del corso e attivazione dei laboratori
- [mese]: esami di prova e certificazioni

**Rischi e come li gestiamo**
- Materiali in inglese: glossario e lezione di terminologia.
- Esaurimento dei crediti: regolamento d'uso e avvisi di spesa.
- Requisiti di età e verifica degli studenti: controllo preventivo.

Resto a disposizione per un incontro.

Cordiali saluti,
[Nome e cognome, ruolo]
