# Scheda dati per la candidatura dell'istituto ad AWS Academy

(La candidatura vera e propria si compila sul portale ufficiale AWS Academy:
https://aws.amazon.com/training/awsacademy. Questa scheda serve a raccogliere i dati prima.)

## L'istituto

- Nome ufficiale: ______
- Forma giuridica (es. Fondazione ITS Academy): ______
- Sede (indirizzo completo): ______
- Sito web: ______
- Percorsi con diploma o certificazione offerti: ______
- Riferimenti di accreditamento (regione / Ministero): ______

## Referente istituzionale (Central Point of Contact, CPOC)

- Nome e cognome: ______
- Ruolo: ______
- Email istituzionale: ______
- Telefono: ______

## Docenti da nominare

| Nome | Email istituzionale | Corso AWS Academy previsto | Esperienza cloud |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |

## Corsi che si intende erogare

| Corso | Periodo | N. studenti | Certificazione obiettivo |
|---|---|---|---|
|  |  |  |  |

## Impegni da confermare

- [ ] Letti i Termini e Condizioni di AWS Academy
- [ ] Almeno un docente accreditato per ogni corso erogato
- [ ] Disponibilità a comunicare con il Program Manager AWS
- [ ] Autorizzazione al trattamento dei dati personali degli studenti
