# Scheda studente: lavorare con GitHub Codespaces

Non devi installare niente: ti serve solo un browser e il tuo account GitHub.

## Aprire il tuo ambiente

1. Apri il **link del compito** che ti ha dato il docente e accetta l'assignment.
2. Nel tuo repository clicca **Code → Codespaces → Create codespace on main**
   (oppure usa il pulsante "Open in Codespaces", se presente).
3. Aspetta circa un minuto: si apre l'editor con terminale, file e ambiente già pronti.

## Lavorare

- Scrivi il codice nell'editor.
- Provalo nel **terminale** in basso (ad esempio `python main.py`, `npm test`, `mvn test`).
- Se il compito ha un sito, apri la scheda **Ports** (Porte) e clicca l'indirizzo.

## Salvare il lavoro (importantissimo!)

Il codespace NON è il tuo archivio: se viene eliminato, i file non salvati su GitHub si perdono.

1. Apri il pannello **Source Control** (icona a rami, a sinistra).
2. Scrivi un messaggio che spieghi cosa hai fatto (es. "Completata la funzione somma").
3. Clicca **Commit**, poi **Sync Changes**.
4. Controlla su github.com che i file siano nel repository: con i test automatici vedrai ✅ o ❌.

## Fermare il codespace

A fine lavoro fermalo, per non consumare ore inutilmente:
menu in basso a sinistra → **Stop Current Codespace**, oppure da https://github.com/codespaces.

## Rimettere in moto un codespace

Torna su https://github.com/codespaces, scegli il tuo codespace e clicca per riaprirlo.

## Se qualcosa non va

| Problema | Cosa fare |
|---|---|
| La pagina non si carica | Chiedi al docente: potrebbe essere bloccata dalla rete della scuola |
| Non riesco a creare il codespace | Chiedi al docente: potrebbero essere finite le ore disponibili |
| L'ambiente non ha le librerie | Premi **F1** e scrivi "Rebuild Container" |
| Ho perso del lavoro | Controlla su github.com se hai fatto il push |
