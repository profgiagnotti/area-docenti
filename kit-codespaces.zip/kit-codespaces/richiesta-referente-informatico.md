# Richiesta al referente informatico: accesso a GitHub Codespaces

Gentile referente,

per le lezioni di [materia] vorrei usare GitHub Codespaces, un ambiente di sviluppo
che funziona interamente nel browser e non richiede installazioni né permessi di
amministratore sui PC del laboratorio.

Per funzionare, il browser deve poter raggiungere almeno:

- github.com e i sottodomini *.github.com
- *.github.dev (editor e Codespaces)
- *.githubusercontent.com
- *.githubassets.com

L'elenco completo e aggiornato dei domini da consentire per Codespaces si trova nella
documentazione ufficiale di GitHub (sezione Codespaces, requisiti di rete): vi chiedo
di verificarlo prima di configurare il firewall.

Il servizio usa connessioni HTTPS e WebSocket: se il filtro della rete li blocca,
l'editor potrebbe non caricarsi.

Possiamo fare insieme una prova da un PC del laboratorio, in orario concordato?

Grazie,
[Nome e cognome]
