# Kit pronto all'uso: GitHub Codespaces per la classe

## Contenuto

| File o cartella | A cosa serve |
|---|---|
| `devcontainer/python/` | Python 3.12 + PyTest |
| `devcontainer/node/` | Node.js 20 |
| `devcontainer/java/` | Java 21 + Maven |
| `devcontainer/cpp/` | C e C++ |
| `devcontainer/php-mysql/` | PHP 8.3 + MySQL 8.4 + phpMyAdmin (con Docker Compose) |
| `scheda-studente.md` | Scheda di una pagina con i passaggi per lo studente |
| `richiesta-referente-informatico.md` | Testo da inviare a chi gestisce la rete della scuola |

## Installazione in 5 passi

1. Scegli la cartella del tuo linguaggio. Copia `devcontainer.json` nel repository modello
   come `.devcontainer/devcontainer.json`.
   (Per `php-mysql/` copia ENTRAMBI i file, `devcontainer.json` e `docker-compose.yml`,
   in una sottocartella di `.devcontainer/`, ad esempio `.devcontainer/php-mysql/`:
   i percorsi nel compose sono scritti per quella posizione.)
2. Aggiungi codice di partenza e README con la consegna.
3. Su GitHub Classroom crea l'assignment e scegli **GitHub Codespaces** come editor.
4. Prova con un account di prova: accetta il compito, apri il codespace, fai commit e push.
5. Distribuisci `scheda-studente.md` e invia la richiesta al referente informatico, se serve.

## Più ambienti nello stesso repository

Se vuoi offrire più configurazioni, mettile in sottocartelle di `.devcontainer/`
(ad esempio `.devcontainer/python/devcontainer.json`): alla creazione del codespace
GitHub chiederà quale usare.

## Attenzione

- Le versioni sono fissate: a inizio anno aggiorna le immagini e riprova tutto.
- Il codespace consuma ore di calcolo: ricorda agli studenti di fermarlo.
- I limiti e le quote gratuite cambiano: verifica la documentazione ufficiale di GitHub.
- Il lavoro va salvato con commit e push, non resta al sicuro nel codespace.
- Questi file sono stati controllati nella sintassi ma NON eseguiti in un vero
  codespace: prova sempre la configurazione con un account di prova prima della lezione.
