# Rubrica di valutazione individuale (lavoro di team)

Studente: ____________  Team: ____________  Periodo: ____________

| Componente (peso) | 1 – Insufficiente | 2 – Base | 3 – Buono | 4 – Eccellente |
|---|---|---|---|---|
| **Lavoro tracciato (40%)** | Pochi task, spesso in ritardo o incompleti; Project non aggiornato | Task completati con ritardi o aiuto continuo | Task completati nei tempi con qualità adeguata e Project aggiornato | Task completati con qualità elevata, stime affidabili, aiuta a ridurre i rischi |
| **Colloquio tecnico (25%)** | Non sa spiegare il proprio codice | Spiega le parti principali con aiuto | Spiega e modifica piccole parti dal vivo | Spiega, giustifica le scelte e propone alternative |
| **Collaborazione (20%)** | Review assenti o superficiali; non partecipa ai daily | Partecipa ma con poca iniziativa | Review utili, aiuta i compagni | Migliora il lavoro del team, risolve conflitti, condivide conoscenze |
| **Retrospettiva e autovalutazione (15%)** | Non riflette sul proprio lavoro | Riflessione generica | Riflessione onesta con esempi | Riflessione critica con azioni di miglioramento concrete |

Voto per componente: ___ / 4

Totale ponderato: ____ / 4  →  voto: ____

## Fonti usate
☐ Project (vista Per persona)  ☐ Pull request e review  ☐ Insights → Contributors  ☐ Daily e verbali
☐ Colloquio  ☐ Valutazione tra pari  ☐ Retrospettiva

## Note del docente
(Il punteggio è un supporto al giudizio: motiva sempre eventuali scostamenti dalla formula.)
