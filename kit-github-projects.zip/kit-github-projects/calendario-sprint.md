# Calendario degli sprint (modello)

## ITIS – quadrimestre di circa 10 settimane
| Periodo | Attività |
|---|---|
| Settimana 1 | **Sprint 0**: team, repository, Project, patto di team, primo backlog |
| Settimane 2-3 | Sprint 1 (planning il primo giorno, review e retrospettiva l'ultimo) |
| Settimane 4-5 | Sprint 2 |
| Settimane 6-7 | Sprint 3 |
| Settimane 8-9 | Sprint 4 |
| Settimana 10 | Chiusura, presentazione finale, colloqui individuali |

## ITS – semestre di 14-16 settimane
| Periodo | Attività |
|---|---|
| Settimana 1 | **Sprint 0** con il Product Owner aziendale |
| Settimane 2-13 | Sei sprint da 2 settimane, con review aperta al referente aziendale |
| Settimane 14-16 | Consolidamento, demo finale, valutazione individuale e tutor aziendale |

## Ritmo di ogni sprint (2 settimane)
| Giorno | Momento |
|---|---|
| 1 | Sprint Planning (45 min) |
| Ogni giorno di lezione | Daily (10 min o scritto) |
| Metà sprint | Controllo del burn-up e delle vista Per persona |
| Ultimo giorno | Sprint Review (15 min) + Retrospettiva (20 min) |

Date del tuo corso: Sprint 1 dal ________ al ________  ·  Sprint 2 dal ________ al ________
