# Retrospettiva – Sprint ____

Data: ____________  Team: ____________  Scrum Master: ____________

## 1. I numeri dello sprint
- Punti pianificati: ____   Punti completati: ____   (velocity)
- Task completati: ____ / ____
- Task passati allo sprint successivo: ____

## 2. Cosa è andato bene
-
-

## 3. Cosa è andato male o ci ha rallentati
-
-

## 4. Cosa proviamo a cambiare nel prossimo sprint (massimo 3 azioni)
| Azione | Chi se ne occupa | Come capiamo se funziona |
|---|---|---|
|  |  |  |
|  |  |  |

## 5. Come stiamo lavorando insieme (1 = male, 5 = molto bene)
- Comunicazione: ___   Distribuzione del lavoro: ___   Qualità del codice: ___   Rispetto degli impegni: ___

## 6. Ringraziamenti
-
