## Cosa cambia

<!-- Descrivi in 2-3 righe cosa fa questa pull request -->

Closes #

## Definition of Done

- [ ] Il codice fa quanto descritto nei criteri di accettazione
- [ ] I test automatici passano
- [ ] Il codice è leggibile e commentato dove serve
- [ ] La documentazione è aggiornata
- [ ] Un compagno ha fatto la review
- [ ] Il task è collegato all'issue (Closes #...)

## Come l'ho provato

<!-- Comandi eseguiti, schermate, casi provati -->

## Co-autori (se hai lavorato in coppia)

<!-- Co-authored-by: Nome <email> nei messaggi di commit -->
