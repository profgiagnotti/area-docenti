# Patto di team

Team: ____________________  Progetto: ____________________  Anno scolastico: ________

## Chi siamo
| Nome | Ruolo nello sprint 1 | Contatto |
|---|---|---|
|  | Scrum Master |  |
|  | Sviluppatore |  |
|  | Sviluppatore |  |
|  | Sviluppatore |  |

(Il ruolo di Scrum Master ruota a ogni sprint.)

## Come lavoriamo
1. Ogni task ha **un solo responsabile**. L'aiuto dei compagni si registra con le review e con `Co-authored-by`.
2. Non teniamo più di **2 task In corso** a testa.
3. Un branch per task, una pull request per task con `Closes #n`.
4. Nessun merge senza almeno **una review** di un compagno.
5. Nessun commit direttamente su `main`.
6. Aggiorniamo lo stato dei task **ogni volta che cambia**, non a fine sprint.
7. Daily: ____ (in aula il ____ / scritto nell'issue Daily entro le ____).

## Cosa facciamo se qualcuno è in difficoltà
- Lo diciamo nel daily, entro un giorno.
- Spezziamo il task o lo affianchiamo a un compagno.
- Avvisiamo il docente se il problema dura più di uno sprint.

## Come decidiamo
- Le priorità le decide il Product Owner.
- Le stime le decidiamo insieme (planning poker).
- Le riassegnazioni dei task si decidono al planning e si motivano.

## Impegni individuali
Ognuno di noi si impegna a lavorare con onestà, a dichiarare l'uso dell'IA quando richiesto, e a non presentare come proprio il lavoro altrui.

Firme: ______________________  ______________________  ______________________  ______________________
