# Scheda di contributo individuale – Sprint ____

Studente: ____________  Team: ____________  Docente: ____________

## Dati dal Project (da report-contributi.py o dalla vista "Per persona")
| Task assegnati | Task completati | Punti assegnati | Punti completati | Punti aperti |
|---|---|---|---|---|
|  |  |  |  |  |

## Pull request e review (ricerca nelle pull request del repository)
- PR create: ____   PR unite: ____   Review fatte: ____
- Qualità media delle review (1-4): ____

## Partecipazione
- Daily presenti: ____ / ____   Sprint Review: ☐ presente  ☐ assente

## Osservazioni del docente
- Punti di forza:
- Da migliorare:
- Domande per il colloquio:

## Azioni concordate con lo studente
1.
2.
