# Scheda di valutazione tra pari (fine sprint)

Valutatore: ____________  Sprint: ____  Team: ____________

Per ogni compagno: 1 = poco, 2 = abbastanza, 3 = bene, 4 = molto bene.
Scrivi sempre un esempio concreto. Questa scheda è riservata al docente.

| Compagno | Contributo al lavoro | Puntualità | Aiuto agli altri | Qualità delle review | Esempio concreto |
|---|---|---|---|---|---|
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |

Cosa ha fatto di più utile per il team questo sprint? ___________________________________

Cosa potrebbe migliorare? ___________________________________

Nota per il docente: la valutazione tra pari è un segnale, non un voto. Va confrontata con i dati del Project e con il colloquio.
