# Ruoli Scrum a scuola

| Ruolo | Chi | Cosa fa | Cosa NON fa |
|---|---|---|---|
| **Product Owner** | Docente o referente aziendale | Decide le priorità del backlog, accetta o rifiuta ciò che viene presentato | Non assegna i singoli task agli studenti |
| **Scrum Master** | Studente, a rotazione ogni sprint | Organizza daily, planning e retrospettiva; rimuove gli ostacoli; chiede aiuto al docente | Non è il capo del team e non ha più compiti degli altri |
| **Team di sviluppo** | 3-5 studenti | Scompone le storie, stima, sviluppa, testa, fa le review | Non cambia le priorità da solo |
| **Docente-coach** | Docente | Osserva, aiuta, valuta il lavoro individuale con i dati del Project | Non scrive il codice per il team |

## Rotazione dello Scrum Master (esempio per 4 sprint)
| Sprint | Scrum Master |
|---|---|
| Sprint 1 |  |
| Sprint 2 |  |
| Sprint 3 |  |
| Sprint 4 |  |

Lo studente che fa lo Scrum Master ha comunque i propri task, un po' più leggeri (ad esempio 20% in meno di punti).
