# Kit pronto all'uso: GitHub Projects con Scrum

## Contenuto

| File / cartella | A cosa serve |
|---|---|
| `issue-templates/.github/` | Modelli di issue (storia utente, bug, task tecnico) e modello di pull request con Definition of Done |
| `esempi/backlog-esempio.csv` | 20 storie di esempio (gestione biblioteca), 70 punti in totale |
| `esempi/items-esempio.json` | Esempio di export del Project per provare il report |
| `scripts/bootstrap-project.sh` | Crea un Project con i campi standard (richiede GitHub CLI) |
| `scripts/crea-etichette.sh` | Crea le etichette standard nel repository |
| `scripts/importa-backlog.py` | Crea gli issue dal CSV e li aggiunge al Project (con `--dry-run`) |
| `scripts/report-contributi.py` | Report del contributo per studente e per sprint |
| `patto-di-team.md`, `definition-of-done.md`, `ruoli-scrum-scuola.md` | Documenti per i team |
| `retrospettiva-template.md`, `scheda-valutazione-tra-pari.md` | Per la fine di ogni sprint |
| `rubrica-valutazione-individuale.md`, `scheda-contributo-sprint.md` | Per il docente |
| `calendario-sprint.md` | Modello di calendario per ITIS e ITS |

## Uso in 5 passi

1. Copia la cartella `.github/` di `issue-templates/` nel repository modello (modelli di issue e di pull request).
2. Crea il Project di ogni team: a mano oppure con `scripts/bootstrap-project.sh`. Poi, dall'interfaccia web,
   aggiungi il campo **Sprint** (Iterazione) e rinomina le opzioni di Status (Backlog, Pronto, In corso, In review, Fatto).
3. Crea le etichette (`scripts/crea-etichette.sh`) e importa il backlog (`scripts/importa-backlog.py`, prima con `--dry-run`).
4. Distribuisci il patto di team e la Definition of Done.
5. A fine sprint esporta i dati e genera il report:

```
gh project item-list NUMERO --owner ORG --limit 500 --format json > items.json
python3 scripts/report-contributi.py items.json --csv report.csv
```

Prova rapida del report: `python3 scripts/report-contributi.py esempi/items-esempio.json`

## Prerequisiti per gli script

- GitHub CLI (`gh`) installata e autenticata con il permesso per i Project: `gh auth refresh -s project`
- Python 3

## Stato di verifica (leggere!)

- `report-contributi.py`: provato sui dati di esempio. Controlla i nomi dei campi sul tuo export reale
  (opzioni `--stato`, `--fatto`, `--sprint`, `--punti`).
- `importa-backlog.py`: provato solo in modalità `--dry-run`.
- `bootstrap-project.sh` e `crea-etichette.sh`: controllata solo la sintassi.
- Nessuno script è stato provato con un vero account GitHub: prova tutto su un'organizzazione di prova.
- I modelli di issue sono file YAML con la sintassi controllata; verifica come appaiono in GitHub.
