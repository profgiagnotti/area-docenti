#!/usr/bin/env python3
"""Report del contributo per studente e per sprint, da un export del Project.

1) Esporta i task del Project con GitHub CLI:
     gh project item-list NUMERO --owner ORG --limit 500 --format json > items.json
2) Genera il report:
     python3 report-contributi.py items.json --csv report.csv

Opzioni utili se i campi del tuo Project hanno nomi diversi:
     --stato "status" --fatto "Fatto" --sprint "sprint" --punti "punti"
I nomi dei campi nell'export sono in minuscolo: verifica aprendo items.json.

Il report conta, per ogni assegnatario: task totali, task completati, punti totali,
punti completati e punti ancora aperti. Un task con più assegnatari conta per ciascuno:
nel corso stabilite che un task ha UN solo responsabile.

Provato su dati di esempio con la struttura attesa; controlla i campi sul tuo export reale.
"""
import argparse, csv, json, sys
from collections import defaultdict

def val(item, key):
    for k, v in item.items():
        if k.lower() == key.lower():
            return v
    return None

def as_text(v):
    if v is None:
        return ""
    if isinstance(v, dict):
        return str(v.get("title") or v.get("name") or "")
    return str(v)

def as_num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("json_file")
    ap.add_argument("--stato", default="status")
    ap.add_argument("--fatto", default="Fatto", help="valore dello stato che indica un task completato")
    ap.add_argument("--sprint", default="sprint")
    ap.add_argument("--punti", default="punti")
    ap.add_argument("--csv", help="scrive il report in questo file CSV")
    a = ap.parse_args()

    data = json.load(open(a.json_file, encoding="utf-8"))
    items = data["items"] if isinstance(data, dict) else data

    stats = defaultdict(lambda: {"task": 0, "fatti": 0, "punti": 0.0, "punti_fatti": 0.0})
    non_assegnati = 0
    for it in items:
        assignees = val(it, "assignees") or []
        if isinstance(assignees, str):
            assignees = [assignees]
        assignees = [x["login"] if isinstance(x, dict) else x for x in assignees]
        sprint = as_text(val(it, a.sprint)) or "(senza sprint)"
        done = as_text(val(it, a.stato)).lower() == a.fatto.lower()
        pts = as_num(val(it, a.punti))
        if not assignees:
            non_assegnati += 1
            continue
        for who in assignees:
            s = stats[(who, sprint)]
            s["task"] += 1
            s["punti"] += pts
            if done:
                s["fatti"] += 1
                s["punti_fatti"] += pts

    rows = []
    for (who, sprint), s in sorted(stats.items()):
        rows.append({
            "studente": who, "sprint": sprint, "task": s["task"], "task_completati": s["fatti"],
            "punti": s["punti"], "punti_completati": s["punti_fatti"],
            "punti_aperti": s["punti"] - s["punti_fatti"],
        })

    head = ["studente", "sprint", "task", "task_completati", "punti", "punti_completati", "punti_aperti"]
    print("{:<18}{:<16}{:>6}{:>13}{:>8}{:>13}{:>9}".format("Studente", "Sprint", "Task", "Completati", "Punti", "Punti fatti", "Aperti"))
    for r in rows:
        print("{:<18}{:<16}{:>6}{:>13}{:>8.0f}{:>13.0f}{:>9.0f}".format(
            r["studente"], r["sprint"], r["task"], r["task_completati"], r["punti"], r["punti_completati"], r["punti_aperti"]))
    tot = defaultdict(float)
    for r in rows:
        tot[r["studente"]] += r["punti_completati"]
    print("\nPunti completati in totale per studente:")
    for who, p in sorted(tot.items(), key=lambda x: -x[1]):
        print(f"  {who}: {p:.0f}")
    if non_assegnati:
        print(f"\nATTENZIONE: {non_assegnati} task senza responsabile (non conteggiati).")

    if a.csv:
        with open(a.csv, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=head)
            w.writeheader(); w.writerows(rows)
        print(f"\nCSV scritto in {a.csv}")

if __name__ == "__main__":
    main()
