#!/usr/bin/env bash
# Crea le etichette standard in un repository.
# Uso: ./crea-etichette.sh ORG/REPO
set -euo pipefail
REPO="${1:?ORG/REPO}"
gh label create storia         --repo "$REPO" --color 1D76DB --description "Funzione dal punto di vista dell'utente" --force
gh label create bug            --repo "$REPO" --color D73A4A --description "Qualcosa non funziona" --force
gh label create tecnico        --repo "$REPO" --color 5319E7 --description "Compito tecnico" --force
gh label create documentazione --repo "$REPO" --color 0E8A16 --description "Documentazione" --force
gh label create bloccato       --repo "$REPO" --color B60205 --description "In attesa di qualcosa o qualcuno" --force
