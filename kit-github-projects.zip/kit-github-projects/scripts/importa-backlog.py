#!/usr/bin/env python3
"""Importa un backlog CSV come issue GitHub e li aggiunge a un Project, impostando i campi.

Prerequisiti: GitHub CLI (gh) installata e autenticata con il permesso 'project':
    gh auth refresh -s project

Esempio (prima con --dry-run per vedere cosa farebbe):
    python3 importa-backlog.py --repo MIA-ORG/team-a-biblioteca --owner MIA-ORG \
        --project 1 --csv ../esempi/backlog-esempio.csv --dry-run

ATTENZIONE: questo script non è stato provato con un vero account GitHub.
Provalo su un repository e un Project di prova.
"""
import argparse, csv, json, subprocess, sys

def run(cmd, dry=False, capture=True):
    if dry:
        print("DRY-RUN:", " ".join(cmd))
        return ""
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print("ERRORE:", " ".join(cmd), "\n", r.stderr, file=sys.stderr)
        sys.exit(1)
    return r.stdout.strip()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True, help="ORG/REPO dove creare gli issue")
    ap.add_argument("--owner", required=True, help="proprietario del Project (organizzazione o utente)")
    ap.add_argument("--project", required=True, type=int, help="numero del Project")
    ap.add_argument("--csv", required=True)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--f-punti", default="Punti")
    ap.add_argument("--f-priorita", default="Priorità")
    ap.add_argument("--f-tipo", default="Tipo")
    ap.add_argument("--f-sprint", default="Sprint")
    a = ap.parse_args()

    labels = {"Storia": "storia", "Bug": "bug", "Tecnico": "tecnico", "Documentazione": "documentazione"}

    project_id, fields = None, {}
    if not a.dry_run:
        project_id = json.loads(run(["gh", "project", "view", str(a.project), "--owner", a.owner, "--format", "json"]))["id"]
        fl = json.loads(run(["gh", "project", "field-list", str(a.project), "--owner", a.owner, "--format", "json"]))
        for f in fl.get("fields", []):
            fields[f["name"]] = f
        for need in (a.f_punti, a.f_priorita, a.f_tipo):
            if need not in fields:
                print(f"ATTENZIONE: il campo '{need}' non esiste nel Project: sarà ignorato.", file=sys.stderr)

    with open(a.csv, newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))

    for r in rows:
        title, body = r["Titolo"], r.get("Descrizione", "")
        cmd = ["gh", "issue", "create", "--repo", a.repo, "--title", title, "--body", body]
        lab = labels.get(r.get("Tipo", ""))
        if lab:
            cmd += ["--label", lab]
        url = run(cmd, a.dry_run)
        add = ["gh", "project", "item-add", str(a.project), "--owner", a.owner, "--url", url or "URL_ISSUE", "--format", "json"]
        out = run(add, a.dry_run)
        if a.dry_run:
            print(f"DRY-RUN: imposta campi per '{title}': Punti={r['Punti']}, Priorità={r['Priorità']}, Tipo={r['Tipo']}, Sprint={r['Sprint']}")
            continue
        item_id = json.loads(out)["id"]

        def edit(field, **kw):
            c = ["gh", "project", "item-edit", "--id", item_id, "--project-id", project_id, "--field-id", field["id"]]
            for k, v in kw.items():
                c += [f"--{k}", str(v)]
            run(c)

        if a.f_punti in fields and r.get("Punti"):
            edit(fields[a.f_punti], number=r["Punti"])
        for fname, key in ((a.f_priorita, "Priorità"), (a.f_tipo, "Tipo")):
            f = fields.get(fname)
            if f and r.get(key):
                opt = next((o for o in f.get("options", []) if o["name"].lower() == r[key].lower()), None)
                if opt:
                    edit(f, **{"single-select-option-id": opt["id"]})
        f = fields.get(a.f_sprint)
        if f and r.get("Sprint"):
            its = (f.get("configuration") or {}).get("iterations", [])
            it = next((i for i in its if i.get("title", "").lower() == r["Sprint"].lower()), None)
            if it:
                edit(f, **{"iteration-id": it["id"]})
        print("OK:", title)

if __name__ == "__main__":
    main()
