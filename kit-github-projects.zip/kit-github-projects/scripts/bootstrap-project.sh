#!/usr/bin/env bash
# Crea un Project con i campi standard del corso e lo collega a un repository.
# Prerequisiti: GitHub CLI autenticata con il permesso project:  gh auth refresh -s project
# Uso: ./bootstrap-project.sh ORG "Team A - Biblioteca" ORG/team-a-biblioteca
#
# ATTENZIONE: script non provato con un vero account GitHub: provalo su un'organizzazione di prova.
set -euo pipefail
OWNER="${1:?organizzazione}"; TITLE="${2:?titolo del project}"; REPO="${3:-}"

NUM=$(gh project create --owner "$OWNER" --title "$TITLE" --format json --jq '.number')
echo "Creato il Project numero $NUM"

gh project field-create "$NUM" --owner "$OWNER" --name "Punti"     --data-type NUMBER
gh project field-create "$NUM" --owner "$OWNER" --name "Priorità"  --data-type SINGLE_SELECT --single-select-options "Alta,Media,Bassa"
gh project field-create "$NUM" --owner "$OWNER" --name "Tipo"      --data-type SINGLE_SELECT --single-select-options "Storia,Bug,Tecnico,Documentazione"
gh project field-create "$NUM" --owner "$OWNER" --name "Ore reali" --data-type NUMBER

if [ -n "$REPO" ]; then
  gh project link "$NUM" --owner "$OWNER" --repo "$REPO"
fi

cat <<MSG

Da fare a mano nell'interfaccia web del Project:
 1. Aggiungere il campo "Sprint" di tipo Iterazione (durata 2 settimane).
 2. Rinominare le opzioni del campo Status in: Backlog, Pronto, In corso, In review, Fatto.
 3. Creare le viste: Backlog (tabella), Sprint corrente (board), Per persona (tabella raggruppata per assegnatario), Roadmap.
 4. Attivare le automazioni (Workflows) per issue chiuso -> Fatto e PR unita -> Fatto.
 5. Impostare i permessi per gli studenti del team.
MSG
