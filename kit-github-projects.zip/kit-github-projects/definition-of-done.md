# Definition of Done (versione base, da adattare)

Un task è **Fatto** quando:

- [ ] Il codice fa quanto descritto nei criteri di accettazione
- [ ] I test automatici passano (GitHub Actions in verde)
- [ ] Il codice è leggibile: nomi chiari, nessun codice morto, commenti dove serve
- [ ] La documentazione è aggiornata (README, commenti, manuale)
- [ ] Un compagno ha fatto la review e i commenti sono stati risolti
- [ ] La pull request è collegata all'issue (Closes #n)
- [ ] Il Project è aggiornato (stato Fatto)

Un incremento di sprint è **Fatto** quando, in più:

- [ ] La versione si avvia seguendo il README
- [ ] È stato creato un tag o una release dello sprint
- [ ] È stata presentata alla Sprint Review
