# Kit pronto all'uso: test automatici con GitHub Actions

## Contenuto

- `workflows/pytest.yml` – Python con PyTest
- `workflows/pytest-con-report.yml` – PyTest con report e riassunto
- `workflows/junit-maven.yml` – Java con JUnit (Maven)
- `workflows/junit-gradle.yml` – Java con JUnit (Gradle)
- `workflows/mocha.yml` – JavaScript con Mocha
- `esempi/python/` e `esempi/node/` – mini-esercizio con test per provare il flusso

## Installazione in 5 passi

1. Crea il repository modello su GitHub (o aprine uno esistente).
2. Crea la cartella `.github/workflows/` e copiaci dentro il workflow del tuo
   linguaggio, rinominandolo `test.yml`.
3. Aggiungi il codice di partenza e i test (oppure parti da una cartella di `esempi/`).
4. Fai un push e controlla nella scheda **Actions** che l'esecuzione parta.
   Se l'esercizio è da completare, i test falliranno: è normale.
5. Nelle impostazioni del repository attiva **Template repository**, poi crea
   l'assignment su GitHub Classroom scegliendolo come modello.

## Prova rapida

Copia `esempi/python/` in un nuovo repository, aggiungi
`workflows/pytest.yml` come `.github/workflows/test.yml` e fai un push:
vedrai 4 test falliti (❌). Completa `src/calcolatrice.py` e rifai il push:
i test diventeranno verdi (✅).

## Attenzione

- Il YAML usa solo spazi (due per livello), mai tabulazioni.
- Gli studenti possono modificare test e workflow nel loro repository:
  non dare permessi di amministrazione e controlla la cronologia dei commit.
- Verifica le quote di minuti gratuiti di GitHub Actions per i repository privati.
