import pytest
from src.calcolatrice import somma, dividi


def test_somma():
    assert somma(2, 3) == 5


def test_somma_negativi():
    assert somma(-2, -3) == -5


def test_dividi():
    assert dividi(10, 2) == 5


def test_dividi_per_zero():
    with pytest.raises(ValueError):
        dividi(1, 0)
