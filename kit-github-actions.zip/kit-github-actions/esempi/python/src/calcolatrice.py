def somma(a, b):
    """Restituisce la somma di a e b."""
    # TODO: lo studente completa la funzione
    return None


def dividi(a, b):
    """Restituisce a / b. Se b è 0 deve sollevare ValueError."""
    # TODO: lo studente completa la funzione
    return None
