const assert = require("assert");
const { somma, dividi } = require("../calcolatrice");

describe("calcolatrice", () => {
  it("somma due numeri", () => {
    assert.strictEqual(somma(2, 3), 5);
  });

  it("divide due numeri", () => {
    assert.strictEqual(dividi(10, 2), 5);
  });

  it("solleva un errore dividendo per zero", () => {
    assert.throws(() => dividi(1, 0));
  });
});
