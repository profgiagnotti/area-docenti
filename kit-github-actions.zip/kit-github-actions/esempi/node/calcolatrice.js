// TODO: lo studente completa le funzioni
function somma(a, b) {
  return null;
}

function dividi(a, b) {
  return null;
}

module.exports = { somma, dividi };
