CREATE TABLE IF NOT EXISTS studenti (
  id SERIAL PRIMARY KEY,
  nome VARCHAR(50) NOT NULL,
  cognome VARCHAR(50) NOT NULL
);

INSERT INTO studenti (nome, cognome) VALUES
  ('Anna', 'Rossi'),
  ('Marco', 'Bianchi'),
  ('Sara', 'Verdi');
