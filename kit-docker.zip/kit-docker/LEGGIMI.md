# Kit pronto all'uso: ambienti Docker per la classe

## Contenuto

| Cartella | Ambiente | Come avviarlo |
|---|---|---|
| `01-python-pytest/` | Python 3.12 + PyTest | `docker compose run --rm python` / `docker compose run --rm test` |
| `02-php-mysql-phpmyadmin/` | PHP 8.3 + Apache + MySQL 8.4 + phpMyAdmin | `docker compose up -d --build` |
| `03-postgres-adminer/` | PostgreSQL 16 + Adminer | `docker compose up -d` |
| `04-node/` | Node.js 20 + Mocha | `docker compose run --rm node` / `docker compose run --rm test` |
| `devcontainer-esempio/` | File per GitHub Codespaces / Dev Containers | vedi `LEGGIMI.txt` |
| `workflow-actions/` | Workflow GitHub Actions che usa Docker Compose | copia in `.github/workflows/` |

Ogni cartella è autonoma: entra nella cartella e lancia i comandi da lì.

## Indirizzi dopo l'avvio

- Sito PHP: http://localhost:8080
- phpMyAdmin: http://localhost:8081 (utente `studente`, password `studente`)
- Adminer: http://localhost:8082 (sistema PostgreSQL, server `db`, utente/password `studente`, database `scuola`)

## Comandi essenziali

| Comando | Cosa fa |
|---|---|
| `docker compose up -d` | Avvia tutto in background |
| `docker compose up -d --build` | Avvia ricostruendo le immagini |
| `docker compose ps` | Mostra cosa è in esecuzione |
| `docker compose logs -f db` | Segue i messaggi del servizio `db` |
| `docker compose run --rm test` | Esegue il servizio `test` una volta |
| `docker compose exec db bash` | Apre una shell nel container `db` |
| `docker compose down` | Spegne tutto, conserva i dati |
| `docker compose down -v` | Spegne tutto e cancella i dati |

## Installazione in 5 passi

1. Copia nel repository modello la cartella dell'ambiente che ti serve.
2. Adatta password, nomi e `init.sql` alla tua materia.
3. Prova: `docker compose up -d`.
4. Simula uno studente al primo avvio: `docker compose down -v` e poi di nuovo `up -d`.
5. Pubblica il modello su GitHub Classroom.

## Attenzione

- Le versioni delle immagini sono fissate: aggiornale a inizio anno e riprova tutto.
- `init.sql` viene eseguito solo quando il volume è vuoto.
- Le password sono didattiche: non usarle mai in ambienti reali.
- Se una porta è occupata, cambia il numero a sinistra (ad esempio `"3307:3306"`).
