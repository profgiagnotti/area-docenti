const { somma } = require("./calcolatrice");

console.log("Ambiente Node pronto! Versione:", process.version);
console.log("2 + 3 =", somma(2, 3));
