const assert = require("assert");
const { somma } = require("../calcolatrice");

describe("calcolatrice", () => {
  it("somma due numeri", () => {
    assert.strictEqual(somma(2, 3), 5);
  });
});
