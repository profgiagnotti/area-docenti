from calcolatrice import somma

if __name__ == "__main__":
    print("Ambiente Python pronto!")
    print("2 + 3 =", somma(2, 3))
