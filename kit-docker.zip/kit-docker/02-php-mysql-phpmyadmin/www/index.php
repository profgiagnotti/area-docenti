<?php
// Prova di connessione: dentro Docker l'host del database è il NOME del servizio ("db"), non "localhost".
try {
    $pdo = new PDO(
        "mysql:host=db;dbname=scuola;charset=utf8mb4",
        "studente",
        "studente",
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $versione = $pdo->query("SELECT VERSION()")->fetchColumn();
    echo "<h1>Ambiente pronto!</h1>";
    echo "<p>PHP " . PHP_VERSION . " &mdash; MySQL " . htmlspecialchars($versione) . "</p>";
    echo "<h2>Studenti</h2><ul>";
    foreach ($pdo->query("SELECT nome, cognome FROM studenti") as $riga) {
        echo "<li>" . htmlspecialchars($riga["nome"] . " " . $riga["cognome"]) . "</li>";
    }
    echo "</ul>";
} catch (PDOException $e) {
    echo "<h1>Errore di connessione</h1><pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}
